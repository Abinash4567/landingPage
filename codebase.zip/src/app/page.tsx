import HeroSection from "./components/hero-section";
import Navbar from "./components/navbar";

export default function Home() {
  return (
    <div className="md:mx-14 mx-8">
      <Navbar/>
      <HeroSection/>
    </div>
  );
}
